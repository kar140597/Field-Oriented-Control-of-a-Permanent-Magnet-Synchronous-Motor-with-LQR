clc
close all
clear all

%% declaration

syms i_d i_q  omega_m real % x
syms V_d V_q % u
syms T_L % d
syms nu1 nu2 r1 r2 real % noise reference control
syms J B R_s N lamb_m real % momentum ,friction ,resistance ,pole pair, flux linkage
syms L_d L_q real

%% Parameter

x = [i_d;i_q;omega_m]; % state
u = [V_d;V_q]; % Control
d = T_L;% disturbance
nu = [nu1;nu2]; % sensor noise
r = [r1;r2];
w = [d;nu;r];% exogenous
y = [i_d;i_q];

%% function
%electric angular speed
omega_e = N*omega_m;
% electric torque
T_e = 3/2*N*(lamb_m*i_q+(L_d - L_q)*i_d*i_q);

%dynamics
dot_i_d = (V_d - R_s*i_d+omega_e*L_q*i_q)/L_d;

dot_i_q = (V_q - R_s*i_q - omega_e*(i_d*L_d + lamb_m))/L_q;

dot_omega_m = (T_e - T_L - B*omega_m)/J;

%function

f = [dot_i_d;dot_i_q;dot_omega_m];%state function
h = [y+nu];%output function
he = r -(y + nu);%error function


%% Linearisation
% state
A = jacobian(f,x);
B1 = jacobian(f,u);
B2 = jacobian(f,w);
%output
C = jacobian(h,x);
D1 = jacobian(h,u);
D2 = jacobian(h,w);
%Error
Ce = jacobian(he,x);
De1 = jacobian(he,u);
De2 = jacobian(he,w);

%% Numerical Form
% state
matlabFunction(A,'File','A');
matlabFunction(B1,'File','B1');
matlabFunction(B2,'File','B2');
%output
matlabFunction(C,'File','C');
matlabFunction(D1,'File','D1');
matlabFunction(D2,'File','D2');
%Error
matlabFunction(Ce,'File','Ce');
matlabFunction(De1,'File','De1');
matlabFunction(De2,'File','De2');
