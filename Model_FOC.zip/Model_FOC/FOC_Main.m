clc
close all
clear all

%% Definition of Equilibrium
%Parameters
syms V_d V_q omega_m real
nu1 = 0;
nu2 = 0;
r1 = 0;
r2 = 5;%ref
R_s = 10e-3;
i_ds = r1;
i_qs = r2;
L_d = 0.5e-3;%H
L_q = 0.8e-3;%H
lamb_m = 0.10;%Wb
N = 12;%no. of pole pairs
J = 0.01;%kg·m²
B = 0.001;%N·m·s/rad Viscous friction coefficient
T_Ls = 8.875;%N.m load torque

%electric dynamic
omega_es = N*omega_m; % electric angular speed
T_es = 3/2*N*(lamb_m*i_qs+(L_d - L_q)*i_ds*i_qs); %electric Torque

% dynamic
dot_i_d = (V_d - R_s*i_ds+omega_es*L_q*i_qs)/L_d;

dot_i_q = (V_q - R_s*i_qs - omega_es*(i_ds*L_d + lamb_m))/L_q;

dot_omega_m = (T_es - T_Ls - B*omega_m)/J;

%solve stedy state
sol = solve([dot_i_d==0,dot_i_q==0,dot_omega_m==0],[V_d,V_q,omega_m]);

%Equilibrium Equation
V_ds = double(sol.V_d);
V_qs = double(sol.V_q);
omega_ms = double(sol.omega_m)
us = [V_ds;V_qs];
rs = [r1;r2];
nus = [nu1;nu2];
xs = [i_ds;i_qs;omega_ms];
ds = T_Ls;
ws = [ds;nus;rs];

ys = [i_ds;i_qs]+nus;

es = rs - ys;

x0 = [0;0;0];

%% Linearization Model

%state linearization
Amatrix = A(B,J,L_d,L_q,N,R_s,i_ds,i_qs,lamb_m,omega_ms);
B1matrix = B1(L_d,L_q);
B2matrix = B2(J);
% output linearization
Cmatrix = C;
D1matrix = D1;
D2matrix = D2;

%error linearization
Cematrix = Ce;
De1matrix = De1;
De2matrix = De2;

%state space
n = size(Amatrix);
[~ , p] = size(B1matrix);
[~ , r] = size(B2matrix);
[q,~] = size(Cmatrix);
[s,~] = size(Cematrix);

%% LQR statefeedback with integral action
Ae = [Amatrix  zeros(3,2) ;
      Cematrix zeros(2,2) ];% extended state


B1e = [B1matrix;
       De1matrix;];

alpha = 0.001;%<0.001
umax=2.12;%2.12
Ceps = eye(5,5);

R = (1/umax^2)*eye(size(B1e,2));%umax=1

eps1max=1;
eps2max=1;
eps3max=1; 
eps4max=0.1;% 0.1 
eps5max=0.1;% 0.1      

Q = inv(length(Ceps)*diag([eps1max^2;eps2max^2;eps3max^2;eps4max^2;eps5max^2]));

Deps = zeros(5,size(B1e,2)) ;
barR = Deps.'*Q*Deps + R;
Am = Ae + alpha*eye(size(Ae));
Bm = B1e;
Qm = Ceps.'*Q*Ceps; % to penalise the cost
Rm = barR;
Sm = (Deps.'*Q*Ceps).';
Em = eye(size(Ae));
Gm = zeros(size(Ae));


[Xm,Km,Lm] = icare(Am,Bm,Qm,Rm,Sm,Em,Gm);

K = -Km;
Ks  = K(:,1:3)
KIA = K(:,4:5)


%% Simulation

model = 'FOC_Model.slx';

% Load model
load_system(model);

% Run simulation
simOut = sim(model,'StopTime','100');

% Show scopes / open model
open_system(model);